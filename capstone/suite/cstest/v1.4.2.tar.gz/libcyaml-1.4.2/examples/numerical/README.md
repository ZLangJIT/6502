Simple LibCYAML example
=======================

This has a simple YAML document for the Fibonacci sequence, and an example
LibCYAML binding to load/free the data from C.

The [tutorial](../../docs/guide.md) explains how this works.
