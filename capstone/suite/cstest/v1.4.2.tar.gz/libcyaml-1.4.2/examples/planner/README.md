Simple LibCYAML example
=======================

This has a simple YAML document for project planning, and an example
LibCYAML binding to load/modify/save/free the data from C.

The C source code is heavliy documented to help explain how to
write a CYAML schema data structure.
